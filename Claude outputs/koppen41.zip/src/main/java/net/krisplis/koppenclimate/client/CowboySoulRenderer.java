package net.krisplis.koppenclimate.client;

import net.krisplis.koppenclimate.KoppenClimateMod;
import net.krisplis.koppenclimate.entity.custom.CowboySoulEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** The cowboy soul, floating over the ground (its shadow stays small and faint). */
public class CowboySoulRenderer extends HumanoidMobRenderer<CowboySoulEntity, CowboySoulModel> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(KoppenClimateMod.MOD_ID, "textures/entity/cowboy_soul.png");

    public CowboySoulRenderer(EntityRendererProvider.Context context) {
        super(context, new CowboySoulModel(context.bakeLayer(CowboySoulModel.LAYER)), 0.35F);
        this.shadowStrength = 0.5F;
    }

    @Override
    public ResourceLocation getTextureLocation(CowboySoulEntity entity) {
        return TEXTURE;
    }
}
