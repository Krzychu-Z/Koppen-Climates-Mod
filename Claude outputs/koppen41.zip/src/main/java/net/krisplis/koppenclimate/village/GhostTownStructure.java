package net.krisplis.koppenclimate.village;

import com.mojang.serialization.MapCodec;
import net.krisplis.koppenclimate.worldgen.biome.GhostTownSites;
import net.krisplis.koppenclimate.worldgen.biome.KoppenBiomeSource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

import java.util.Arrays;
import java.util.Optional;

/**
 * A ghost town (GhostTownPiece). There is one at every ghost town site (GhostTownSites): out in the Lush desert
 * (BSh), in the middle of its patch of yellow-skied ghost town biome. Its structure set tries every chunk; only the
 * chunk holding a site's centre starts a town.
 */
public class GhostTownStructure extends Structure {
    public static final MapCodec<GhostTownStructure> CODEC = simpleCodec(GhostTownStructure::new);

    public GhostTownStructure(StructureSettings settings) {
        super(settings);
    }

    @Override
    public Optional<GenerationStub> findGenerationPoint(GenerationContext context) {
        if (!(context.biomeSource() instanceof KoppenBiomeSource source)) return Optional.empty();
        ChunkPos chunk = context.chunkPos();
        Optional<GhostTownSites.Site> found = source.ghostTownSite(chunk.getMiddleBlockX(), chunk.getMiddleBlockZ(),
                context.randomState().sampler());
        if (found.isEmpty()) return Optional.empty();
        GhostTownSites.Site site = found.get();
        if (SectionPos.blockToSectionCoord(site.x()) != chunk.x || SectionPos.blockToSectionCoord(site.z()) != chunk.z) {
            return Optional.empty();
        }
        // the town is levelled at the middle height of the ground under it
        int[] heights = new int[9];
        int i = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                heights[i++] = context.chunkGenerator().getBaseHeight(site.x() + dx * 30, site.z() + dz * 16,
                        Heightmap.Types.WORLD_SURFACE_WG, context.heightAccessor(), context.randomState()) - 1;
            }
        }
        Arrays.sort(heights);
        int floor = Math.max(context.chunkGenerator().getSeaLevel() + 1, heights[4]);
        BlockPos centre = new BlockPos(site.x(), floor, site.z());
        long seed = context.random().nextLong();
        return Optional.of(new GenerationStub(centre, builder -> builder.addPiece(new GhostTownPiece(centre, seed))));
    }

    @Override
    public StructureType<?> type() {
        return VillageRegistry.GHOST_TOWN.get();
    }
}
