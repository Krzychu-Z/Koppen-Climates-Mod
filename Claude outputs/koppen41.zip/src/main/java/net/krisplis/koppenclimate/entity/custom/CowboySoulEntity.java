package net.krisplis.koppenclimate.entity.custom;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * The cowboy soul: the restless dead of the ghost towns (GhostTownPiece). A zombie of a gunslinger in his hat and
 * long coat, grey and gaunt, with great empty eye sockets, that drifts about a block above the ground instead of
 * walking, trailing soul wisps. It comes out only at night (it's a monster of the ghost town biome) and fades away
 * at sunrise; it never burns, never drowns, never turns into anything, and never calls other zombies for help.
 */
public class CowboySoulEntity extends Zombie {
    // how high it floats over the ground, and how much it bobs
    private static final double HOVER = 0.9, BOB = 0.15;

    public CowboySoulEntity(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 26.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.ATTACK_DAMAGE, 5.0)
                .add(Attributes.ARMOR, 2.0)
                .add(Attributes.FOLLOW_RANGE, 40.0)
                .add(Attributes.SPAWN_REINFORCEMENTS_CHANCE, 0.0);
    }

    @Override
    protected void randomizeReinforcementsChance() {
        this.getAttribute(Attributes.SPAWN_REINFORCEMENTS_CHANCE).setBaseValue(0.0);
    }

    @Override
    public void tick() {
        this.setNoGravity(true);
        super.tick();
        // float above the ground, bobbing gently
        double ground = this.groundBelow();
        double target = ground + HOVER + BOB * Math.sin(this.tickCount * 0.08 + this.getId());
        Vec3 v = this.getDeltaMovement();
        this.setDeltaMovement(v.x, (target - this.getY()) * 0.12, v.z);
        if (this.level().isClientSide) {
            if (this.random.nextInt(4) == 0) {
                this.level().addParticle(ParticleTypes.SOUL, this.getRandomX(0.5), this.getY() + this.random.nextDouble() * 0.4,
                        this.getRandomZ(0.5), 0.0, -0.02, 0.0);
            }
            return;
        }
        // at sunrise it fades away
        if (this.level().isDay() && this.tickCount % 20 == 0 && !this.hasCustomName()) {
            ((ServerLevel) this.level()).sendParticles(ParticleTypes.SOUL, this.getX(), this.getY() + 1.0, this.getZ(), 20, 0.3, 0.6, 0.3, 0.02);
            this.playSound(SoundEvents.SOUL_ESCAPE.value(), 1.0F, 0.8F);
            this.discard();
        }
    }

    /** The top of the ground under it (up to 6 blocks down). */
    private double groundBelow() {
        BlockPos.MutableBlockPos pos = this.blockPosition().mutable();
        for (int i = 0; i < 6; i++) {
            BlockState s = this.level().getBlockState(pos);
            if (!s.getCollisionShape(this.level(), pos).isEmpty() || !s.getFluidState().isEmpty()) {
                double top = s.getCollisionShape(this.level(), pos).isEmpty() ? 1.0 : s.getCollisionShape(this.level(), pos).max(net.minecraft.core.Direction.Axis.Y);
                return pos.getY() + top;
            }
            pos.move(0, -1, 0);
        }
        return this.getY() - HOVER;
    }

    // it never touches the ground, so it keeps working out its way as it drifts along
    @Override
    protected net.minecraft.world.entity.ai.navigation.PathNavigation createNavigation(Level level) {
        return new net.minecraft.world.entity.ai.navigation.GroundPathNavigation(this, level) {
            @Override
            protected boolean canUpdatePath() {
                return true;
            }
        };
    }

    @Override
    protected void populateDefaultEquipmentSlots(net.minecraft.util.RandomSource random, net.minecraft.world.DifficultyInstance difficulty) {
        // no weapons: its touch is enough
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
    }

    @Override
    protected boolean isSunSensitive() {
        return false;
    }

    @Override
    protected boolean convertsInWater() {
        return false;
    }

    @Override
    public boolean canBreakDoors() {
        return false;
    }

    @Override
    protected boolean supportsBreakDoorGoal() {
        return false;
    }

    @Override
    public boolean isBaby() {
        return false;
    }

    @Override
    public void setBaby(boolean baby) {
    }

    @Override
    protected ItemStack getSkull() {
        return ItemStack.EMPTY;
    }

    @Override
    public float getVoicePitch() {
        return 0.55F + this.random.nextFloat() * 0.1F;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return this.random.nextInt(3) == 0 ? SoundEvents.SOUL_ESCAPE.value() : SoundEvents.ZOMBIE_AMBIENT;
    }

    @Override
    protected SoundEvent getStepSound() {
        return SoundEvents.SOUL_ESCAPE.value();
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        // it floats: no footsteps
    }
}
